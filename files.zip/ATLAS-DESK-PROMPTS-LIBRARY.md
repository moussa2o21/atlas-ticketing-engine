# ATLAS — AppLogica Desk
# AI Prompts Library

**Document ID:** ATLAS-DESK-PROMPTS-v1.0  
**Product:** AppLogica Desk (ATLAS-ITSM)  
**Wave:** Wave 3 — Enterprise Products  
**Date:** March 01, 2026  
**Parent Document:** ATLAS-PROMPTS-LIBRARY-CORE.docx  

---

## Overview

This library contains all structured AI prompts for the development of AppLogica Desk. Each prompt follows the standard ATLAS 6-part template:

```
[ROLE]           — AI persona and expertise domain
[CONTEXT]        — Product, technology, and business context
[TASK]           — Specific deliverable requested
[CONSTRAINTS]    — Non-negotiable rules and boundaries
[OUTPUT FORMAT]  — Expected structure of the response
[EXAMPLE]        — Reference examples (where applicable)
```

Prompts are organized by engineering domain. All prompts enforce ATLAS platform standards, multi-tenancy, Arabic/RTL support, and AI Gateway routing.

---

## Section 1 — Architecture & Domain Design

### Prompt D-ARCH-01: Incident Domain Model

```
[ROLE]
You are a Senior Domain Architect with deep expertise in ITIL v4 Incident Management
and domain-driven design in .NET 8.

[CONTEXT]
Product: AppLogica Desk — Enterprise ITSM Platform
Tech: .NET 8 Clean Architecture, PostgreSQL 15, RabbitMQ, MassTransit
Standard: ITIL v4 Incident Management practice
Multi-tenancy: Schema-per-tenant isolation mandatory
Requirements:
- Full ITIL-aligned incident lifecycle
- Priority matrix (Impact × Urgency → Priority)
- Major Incident mode for P0/P1
- Full audit trail on every state transition
- Domain events for all state changes

[TASK]
Design the complete Incident domain model for AppLogica Desk.

[CONSTRAINTS]
- Every entity must include: TenantId, CreatedAt, UpdatedAt, CreatedBy, UpdatedBy
- Apply soft delete: IsDeleted, DeletedAt, DeletedBy
- State machine must be explicit — no implicit status strings
- Domain events must be published on: Created, Assigned, Escalated, Resolved, Closed
- No direct database calls from domain layer
- AI classification fields must be nullable (AI can be unavailable)

[OUTPUT FORMAT]
## Incident Domain Model
### Core Entity: Incident
### Value Objects
### Enumerations (IncidentStatus, Priority, Impact, Urgency, IncidentType)
### State Machine (states, transitions, guards, actions)
### Domain Events (one per transition)
### Aggregate Relationships
### Business Rules & Invariants
### Repository Interface (IIncidentRepository)
```

---

### Prompt D-ARCH-02: SLA Engine Architecture

```
[ROLE]
You are a Backend Architect specializing in SLA management systems,
background processing, and high-availability timer design in .NET 8.

[CONTEXT]
Product: AppLogica Desk — SLA & Operational Governance Module
Tech: .NET 8, PostgreSQL, Redis, Hangfire, RabbitMQ
Requirements:
- Multiple SLA policies per tenant (by priority, ticket type, customer tier)
- Response Time and Resolution Time tracking independently
- Business hours support with per-tenant holiday calendars
- SLA pause/resume (pending customer, third-party hold, maintenance window)
- Breach prediction with configurable warning threshold (e.g., 80% elapsed)
- OLA tracking (internal team commitments)
- High-volume: 100,000+ active SLA timers across tenants

[TASK]
Design the complete SLA Engine for AppLogica Desk.

[CONSTRAINTS]
- SLA calculation must NEVER be performed inline in API handlers
- All timer state stored in PostgreSQL (not Redis) for durability
- Redis used for real-time cache and pub/sub breach warnings only
- Must support timezone-aware business hours (tenant timezone from ATLAS Identity)
- Breach events published to ATLAS Event Bus: desk.sla.warning, desk.sla.breached
- Hangfire jobs must be idempotent and re-runnable
- Must handle priority change mid-SLA (recalculate remaining time)

[OUTPUT FORMAT]
## SLA Engine Architecture
### Domain Model (SlaPolicy, SlaTimer, SlaBreachRecord, BusinessHoursCalendar)
### State Machine (Active, Paused, Warning, Breached, Met, Voided)
### Calculation Algorithm (with business hours pseudo-code)
### Pause/Resume Logic
### Breach Prediction Algorithm
### Background Job Design (Hangfire job schedule and retry policy)
### Redis Integration (pub/sub for real-time breach alerts)
### Event Bus Integration (desk.sla.warning, desk.sla.breached)
### Performance Considerations (indexing, batch processing)
### Edge Cases (priority change, timezone crossing, calendar boundary)
```

---

### Prompt D-ARCH-03: Change Management CAB Workflow

```
[ROLE]
You are a Senior Backend Architect with expertise in approval workflow
engines, ITIL Change Management, and state machine design.

[CONTEXT]
Product: AppLogica Desk — Change Management Module
Tech: .NET 8, PostgreSQL, SignalR, RabbitMQ
Standard: ITIL v4 Change Enablement practice
Change Types: Standard (pre-approved), Normal (CAB review), Emergency (fast-track)
Requirements:
- Configurable approval chains per change type and risk level
- CAB meeting scheduling with agenda and digital voting
- Change calendar with conflict detection
- Rollback plan capture as structured data
- Post-Implementation Review (PIR) workflow
- Emergency change expedited path with mandatory PIR

[TASK]
Design the Change Management workflow engine including CAB approval process.

[CONSTRAINTS]
- Standard Changes bypass CAB (template-based pre-approval)
- Emergency Changes must have a post-implementation review mandatory
- CAB voting: quorum rules configurable per tenant
- Change calendar conflict detection must flag overlapping changes on shared CIs
- All state transitions must emit domain events
- Tenant-isolated: CAB members, approval chains, and calendars are tenant-specific

[OUTPUT FORMAT]
## Change Management Workflow Design
### Change Types & Approval Paths (decision tree)
### Domain Model (ChangeRequest, CabMeeting, ApprovalRecord, ChangeTask)
### State Machine per Change Type
### CAB Voting Engine Design
### Conflict Detection Algorithm (Change Calendar)
### Emergency Fast-Track Flow
### Domain Events
### API Contracts (RFC creation, CAB vote, implementation confirmation)
```

---

### Prompt D-ARCH-04: CMDB Design

```
[ROLE]
You are a Domain Architect specializing in Configuration Management
Database (CMDB) design for ITSM platforms.

[CONTEXT]
Product: AppLogica Desk — Lightweight CMDB Module
Tech: .NET 8, PostgreSQL (graph traversal via recursive CTE), Elasticsearch
Standard: ITIL v4 Service Configuration Management (lightweight, not full ITIL CMDB)
Requirements:
- CI types: Servers, Applications, Services, Network Devices, Databases, End-user Devices
- Relationship types: Runs-On, Depends-On, Connected-To, Hosted-By, Managed-By
- Impact radius: given a CI, what incidents/changes are affected?
- Integration hooks for Azure Monitor, AWS Config (webhook-based)
- Change history per CI (full immutable audit log)

[TASK]
Design the lightweight CMDB schema and impact analysis engine for AppLogica Desk.

[CONSTRAINTS]
- NOT a full discovery CMDB — manual entry + webhook-based auto-sync only
- Relationship graph stored in PostgreSQL (no separate graph database required)
- Impact analysis must execute in < 500ms for graphs up to 500 CIs
- Every CI change must create an immutable audit record
- Multi-tenant: CIs and relationships are tenant-scoped
- CI types must be extensible (tenant-defined custom CI types)

[OUTPUT FORMAT]
## CMDB Design
### CI Domain Model (ConfigurationItem, CiRelationship, CiAttribute, CiType)
### Relationship Graph Schema (adjacency list in PostgreSQL)
### Impact Analysis Algorithm (recursive CTE with depth limit)
### CI History & Audit Model
### Custom CI Type System
### Integration Webhook Design (Azure Monitor, AWS Config)
### API Contracts (CI CRUD, relationship management, impact query)
### Performance Benchmarks and Index Strategy
```

---

## Section 2 — Backend Engineering

### Prompt D-BE-01: Incident API Implementation

```
[ROLE]
You are a Senior .NET 8 Backend Developer with expertise in Clean Architecture,
CQRS, and MediatR patterns.

[CONTEXT]
Product: AppLogica Desk — Incident Management API
Tech: .NET 8, Clean Architecture, MediatR, FluentValidation, PostgreSQL, EF Core
Requirements:
- Incident CRUD operations
- State machine transitions (assign, escalate, resolve, close)
- Bulk operations (bulk assign, bulk close)
- Rich filtering (by status, priority, assignee, queue, date range, CI)
- Full-text search integration (Elasticsearch)
- Real-time updates via SignalR when incidents change

[TASK]
Implement the {{COMMAND_NAME}} command/query handler for the Incident domain.

[CONSTRAINTS]
- All handlers must be in Application layer — no domain logic in handlers
- TenantId must be resolved from ATLAS Identity context, never from request body
- FluentValidation for all input validation
- EF Core repository must filter by TenantId on every query
- State transitions must invoke domain state machine, not raw status updates
- Publish domain event after every state change via MassTransit
- No direct SignalR calls from handlers — use domain events → event handler → SignalR hub

[OUTPUT FORMAT]
### Command/Query Definition
### Validator (FluentValidation)
### Handler Implementation
### Repository Method
### Domain Event Publication
### Controller Endpoint
### Unit Tests (xUnit + Moq)
```

---

### Prompt D-BE-02: Service Catalog & Fulfillment Engine

```
[ROLE]
You are a Backend Architect designing a workflow engine for IT service catalog
fulfillment with dynamic form handling and multi-stage approvals.

[CONTEXT]
Product: AppLogica Desk — Service Request & Catalog Module
Tech: .NET 8, PostgreSQL (JSONB for form schemas), RabbitMQ, Hangfire
Requirements:
- Service catalog with categorized service items
- Dynamic form builder: form schema stored as JSON, rendered on frontend
- Multi-stage approval workflows: sequential and parallel approval paths
- Fulfillment task checklists linked to request lifecycle
- SLA per catalog item (independent from incident SLA policies)
- Tenant-configurable catalog (admin creates service items)

[TASK]
Design and implement the Service Catalog fulfillment engine including
dynamic form handling and approval workflow orchestration.

[CONSTRAINTS]
- Form schemas stored as JSONB in PostgreSQL (not separate form engine)
- Approval chain must support: Sequential, Parallel, Any-One-Of patterns
- Delegation: approver can delegate to another user with time limit
- Auto-escalate on approval timeout (configurable per step)
- Approval state changes publish events to ATLAS Event Bus
- Fulfillment task completion tracked independently from request status

[OUTPUT FORMAT]
## Service Catalog Fulfillment Engine
### Domain Model (ServiceItem, ServiceRequest, ApprovalWorkflow, ApprovalStep, FulfillmentTask)
### Form Schema Design (JSONB structure)
### Approval Orchestration State Machine
### Delegation Logic
### Timeout and Auto-Escalation
### API Contracts
### Background Job (approval timeout checker)
```

---

### Prompt D-BE-03: Knowledge Base with AI Article Generation

```
[ROLE]
You are a Senior Backend Developer building an AI-augmented knowledge base
for an ITSM platform in .NET 8.

[CONTEXT]
Product: AppLogica Desk — Knowledge Management Module
Tech: .NET 8, PostgreSQL, Elasticsearch, ATLAS AI Gateway (Azure OpenAI backend)
Requirements:
- Article authoring with version control (Draft → Review → Published → Archived)
- Category and tag taxonomy (hierarchical, tenant-configurable)
- Full-text search with relevance scoring (Elasticsearch)
- AI-assisted article generation from resolved incident notes
- AI article suggestion during incident creation (RAG pattern via ATLAS AI Gateway)
- Article feedback and rating system

[TASK]
Implement the Knowledge Base module including the AI article generation
pipeline triggered on incident resolution.

[CONSTRAINTS]
- AI article generation triggered ONLY on incident resolution, not close
- Generated article goes to Draft status — human review MANDATORY before publish
- AI generation routed through ATLAS AI Gateway (/v1/actions endpoint)
- Elasticsearch index synced asynchronously via MassTransit consumer
- Article version history immutable — no hard deletes of versions
- RTL metadata field required for Arabic articles

[OUTPUT FORMAT]
### KnowledgeArticle Domain Model (with versioning)
### Article Lifecycle State Machine
### AI Generation Pipeline (trigger → AI Gateway → draft creation)
### AI Prompt Template (for article generation from incident data)
### Elasticsearch Index Schema
### Sync Consumer (MassTransit)
### RAG Integration (suggestion endpoint during incident intake)
### API Contracts
```

---

## Section 3 — Frontend Engineering

### Prompt D-FE-01: Agent Unified Inbox

```
[ROLE]
You are a Senior Frontend Developer building an enterprise agent workspace
for an ITSM platform using React 18, TypeScript, and Ant Design.

[CONTEXT]
Product: AppLogica Desk — Agent Unified Inbox
Tech: React 18, TypeScript, Ant Design, React Query, SignalR, i18next
Requirements:
- Unified view: Incidents, Requests, Changes in a single configurable inbox
- Real-time updates when items are assigned, updated, or SLA-warned
- Advanced filters: status, priority, queue, assignee, SLA risk, date range
- Bulk actions: bulk assign, bulk escalate, bulk close
- Custom saved views per agent (persistent)
- Keyboard shortcuts for power users
- Full RTL support for Arabic locale

[TASK]
Create the {{COMPONENT_NAME}} component for the AppLogica Desk agent inbox.

[CONSTRAINTS]
- React Query for all data fetching (no direct fetch/axios in components)
- SignalR subscription managed via custom hook (useInboxRealtime)
- Virtual scrolling required for lists > 200 items (react-virtual)
- Saved views persisted to backend (not localStorage)
- All ARIA labels required (WCAG 2.1 AA)
- RTL: use logical CSS properties (margin-inline-start not margin-left)
- SLA risk indicator: color-coded (green / amber / red) with accessible labels
- Never show raw tenant IDs — always resolved display names

[OUTPUT FORMAT]
### Component Architecture
### Props Interface (TypeScript)
### Data Fetching Strategy (React Query hooks)
### Real-time Integration (useInboxRealtime hook)
### Filter State Management
### Virtual Scroll Implementation
### RTL Adaptation
### Accessibility Implementation
### Unit Tests (React Testing Library)
```

---

### Prompt D-FE-02: Change Calendar UI

```
[ROLE]
You are a Senior Frontend Developer specializing in calendar and scheduling
UI components in React with TypeScript.

[CONTEXT]
Product: AppLogica Desk — Change Management Calendar
Tech: React 18, TypeScript, Ant Design, FullCalendar (or custom)
Requirements:
- Weekly and monthly calendar views of scheduled changes
- Color-coding by change type (Standard / Normal / Emergency) and status
- Conflict indicators when multiple changes target overlapping CIs
- Click-to-open RFC detail drawer
- Drag-to-reschedule with confirmation (Normal/Emergency changes only)
- Timezone-aware display (agent's local timezone vs change's scheduled timezone)
- RTL support for Arabic locale

[TASK]
Design and implement the Change Calendar component for AppLogica Desk.

[CONSTRAINTS]
- Calendar must display changes from current week ± 4 weeks default range
- Conflicts highlighted with visual overlap indicator (not blocking navigation)
- Drag-to-reschedule only available for changes in Scheduled or Approved status
- Reschedule triggers confirmation modal with impact summary
- Emergency changes displayed with red border and priority badge
- RTL: calendar weeks start Sunday for MENA locale

[OUTPUT FORMAT]
### Calendar Component Architecture
### Data Model (ChangeCalendarEvent interface)
### Conflict Detection Logic (frontend-side from API data)
### Color Coding Schema
### Drag-to-Reschedule Implementation
### Timezone Handling
### RTL Configuration
### Accessibility (keyboard navigation of calendar)
```

---

### Prompt D-FE-03: SLA Dashboard

```
[ROLE]
You are a Senior Frontend Developer and data visualization specialist
building operational dashboards for ITSM teams.

[CONTEXT]
Product: AppLogica Desk — SLA Reporting Dashboard
Tech: React 18, TypeScript, Ant Design, Recharts, React Query
Audience: IT managers, service desk team leads
Requirements:
- Real-time SLA compliance rate (response + resolution)
- SLA breach heatmap by day/hour
- MTTR and MTTD trend charts
- By-team and by-priority breakdown
- Breach prediction indicator (% of open tickets at risk)
- Exportable to PDF and Excel
- Date range selector (today, 7d, 30d, 90d, custom)

[TASK]
Build the SLA Operations Dashboard component for AppLogica Desk.

[CONSTRAINTS]
- Dashboard data fetched via React Query with 60-second auto-refresh
- Charts must be responsive (mobile-aware breakpoints)
- All numeric KPIs show delta vs previous period (↑↓ with %)
- Accessible colors: never rely on color alone to encode data
- Export uses backend PDF/Excel endpoint — no client-side generation
- RTL: chart axis labels and legends must support Arabic
- Empty state: show guidance when no data in range (not just blank)

[OUTPUT FORMAT]
### Dashboard Component Architecture
### KPI Card Component
### SLA Compliance Trend Chart
### Breach Heatmap Implementation
### MTTR/MTTD Chart
### Breach Risk Indicator Widget
### Date Range Selector
### Export Integration
### Responsive and RTL Strategy
```

---

## Section 4 — AI Layer

### Prompt D-AI-01: ITSM Copilot System Prompt

```
[ROLE]
You are an AI Product Manager and Prompt Engineer designing the system
prompt for an ITSM AI Copilot integrated into AppLogica Desk.

[CONTEXT]
Product: AppLogica Desk — AI Copilot for IT Agents
Integration: ATLAS AI Gateway (/v1/chat endpoint)
Audience: IT support agents (Tier 1–3), ITSM administrators
Capabilities:
- Answer questions about ITIL processes as implemented in Desk
- Explain incident/request/change status and history in natural language
- Guide agents through workflows (e.g., "how do I escalate to major incident?")
- Suggest KB articles relevant to the current incident
- Draft initial resolution notes based on incident timeline
- Explain SLA status and breach risk in plain language

[TASK]
Write the production system prompt for the AppLogica Desk AI Copilot.

[CONSTRAINTS]
- Must NOT take autonomous actions — advisory only in copilot mode
- Must NOT reveal internal system data (tenant schemas, infrastructure details)
- Must cite KB articles by ID and title when suggesting knowledge content
- Must clearly label AI-generated content suggestions as "AI Draft — Review Required"
- Must respond in the same language as the user query (Arabic or English)
- Responses must be concise — agents need quick answers, not essays
- Must escalate ambiguous compliance questions to human team leads

[OUTPUT FORMAT]
### Full Production System Prompt (ready to paste into AI Gateway config)
### Persona Definition
### Capability Boundaries
### Escalation Triggers
### Response Style Rules
### Example Interactions (Arabic + English)
```

---

### Prompt D-AI-02: Incident Smart Classification

```
[ROLE]
You are an AI/ML Engineer designing an automated ticket classification
pipeline for an enterprise ITSM platform.

[CONTEXT]
Product: AppLogica Desk — AI Smart Classification
Integration: ATLAS AI Gateway (/v1/actions endpoint)
Input: Raw incident title + description (Arabic or English)
Required Outputs:
- Category (from tenant's configured category tree)
- Subcategory
- Priority suggestion (Critical / High / Medium / Low) with confidence score
- Affected CI (matched from CMDB, if identifiable)
- Recommended assignment queue

[TASK]
Design the Incident Smart Classification pipeline including the classification
prompt, confidence thresholds, and fallback behavior.

[CONSTRAINTS]
- Classification prompt must include few-shot examples (minimum 3 per category)
- Confidence < 70% → present as suggestion, agent must confirm
- Confidence >= 70% → auto-apply, agent can override
- Confidence >= 90% → auto-apply silently (logged but no UI prompt)
- AI output must be parseable JSON — no free-text classification responses
- Tenant-specific category trees must be injected into prompt context dynamically
- Arabic input must not be transliterated — process in original Arabic
- All classifications logged to audit trail with confidence score

[OUTPUT FORMAT]
### Classification Prompt Template (with few-shot structure)
### JSON Output Schema
### Confidence Threshold Logic
### Tenant Context Injection Strategy
### Fallback Behavior (AI unavailable)
### Audit Log Schema
### Evaluation Dataset Design (how to measure classification accuracy)
```

---

### Prompt D-AI-03: RAG Knowledge Retrieval Pipeline

```
[ROLE]
You are an AI Engineer specializing in Retrieval-Augmented Generation (RAG)
pipelines for enterprise knowledge management.

[CONTEXT]
Product: AppLogica Desk — Intelligent Knowledge Retrieval
Integration: ATLAS AI Gateway (/v1/rag endpoint)
Knowledge Sources: KB articles, resolved incident notes, CMDB CI descriptions
Use Cases:
1. During incident creation: suggest relevant KB articles
2. During resolution: suggest similar resolved incidents
3. Agent copilot Q&A: answer questions using KB content
Corpus Size: Up to 50,000 articles per tenant

[TASK]
Design the RAG pipeline for AppLogica Desk knowledge retrieval,
including indexing strategy, retrieval logic, and reranking.

[CONSTRAINTS]
- Embeddings generated via ATLAS AI Gateway (no direct embedding API calls)
- Vector index stored per-tenant (tenant isolation mandatory)
- Hybrid retrieval: keyword (Elasticsearch BM25) + semantic (vector) combined
- Reranking: top-20 candidates → reranked to top-5 for presentation
- Context window budget: max 4,000 tokens per RAG response
- Stale article detection: articles older than 180 days flagged in results
- Arabic content must use Arabic-compatible embedding model (verified through AI Gateway)

[OUTPUT FORMAT]
### RAG Architecture Diagram (text-based)
### Indexing Pipeline (article → chunk → embed → store)
### Chunking Strategy (chunk size, overlap, metadata fields)
### Retrieval Strategy (hybrid BM25 + vector)
### Reranking Logic
### Context Assembly for LLM Prompt
### Freshness and Staleness Handling
### Tenant Isolation in Vector Store
### Performance SLAs (retrieval target: < 300ms P95)
```

---

### Prompt D-AI-04: AI Anomaly Detection for Incident Spikes

```
[ROLE]
You are an AI/ML Engineer designing anomaly detection for operational
intelligence in an enterprise ITSM platform.

[CONTEXT]
Product: AppLogica Desk — AI Reporting & Insights
Integration: ATLAS AI Gateway (/v1/actions endpoint)
Use Cases:
- Detect abnormal spikes in incident volume by category, CI, or time
- Identify recurring incident patterns that indicate an undetected Problem
- Detect SLA breach clusters suggesting systemic issues
- Generate natural language summaries explaining detected anomalies
Reporting Cycle: Triggered on-demand and scheduled (daily/weekly)

[TASK]
Design the anomaly detection pipeline and natural language narrative
generation for AppLogica Desk reporting.

[CONSTRAINTS]
- Anomaly detection uses statistical baselines from rolling 30-day window
- Minimum signal: anomaly must deviate > 2σ from baseline to trigger
- False positive suppression: known maintenance windows excluded from analysis
- NL narrative generated via ATLAS AI Gateway with structured data as context
- Narrative length: 150–300 words per insight card
- Narratives generated in tenant's preferred language (Arabic or English)
- All AI-generated narratives labeled and include confidence indicator

[OUTPUT FORMAT]
### Anomaly Detection Algorithm
### Baseline Calculation Method
### Spike Detection Logic
### Pattern Recognition (recurring incidents → problem candidates)
### Narrative Generation Prompt Template
### Output Data Model (AnomalyInsight)
### Scheduling Design (Hangfire job)
### False Positive Suppression Strategy
```

---

## Section 5 — Database & Infrastructure

### Prompt D-DB-01: Core Schema Design

```
[ROLE]
You are a Database Architect specializing in PostgreSQL schema design
for multi-tenant SaaS ITSM platforms.

[CONTEXT]
Product: AppLogica Desk — Core Database Schema
Tech: PostgreSQL 15, EF Core 8, schema-per-tenant isolation
Entities: Incidents, ServiceRequests, Problems, ChangeRequests, CIs,
          SLAPolicies, KnowledgeArticles, Agents, Teams, Queues
Requirements:
- Full-text search indexes (incidents, KB articles)
- SLA timer indexes (efficient background job queries)
- Audit trail table (append-only, immutable)
- JSONB for: custom fields, form schemas, CI attributes
- Partitioning consideration for large tenants

[TASK]
Generate the complete PostgreSQL DDL for the AppLogica Desk core schema.

[CONSTRAINTS]
- Schema name is tenant-provisioned dynamically (schema_per_tenant pattern)
- All tables include: id UUID DEFAULT gen_random_uuid(), tenant_id UUID NOT NULL
- All tables include: created_at, updated_at, created_by, updated_by
- Soft delete: is_deleted BOOLEAN DEFAULT FALSE, deleted_at, deleted_by
- SLA timer table must be indexed on: due_at, status, tenant_id (composite)
- Audit table: append-only, no UPDATE or DELETE permitted (enforced via RLS or trigger)
- All FK constraints within tenant schema (no cross-schema FKs)

[OUTPUT FORMAT]
### Complete DDL (CREATE TABLE statements with all constraints)
### Index Definitions (explain reasoning for each)
### Full-text Search Index Configuration
### Audit Trigger Implementation
### Partition Strategy Recommendation (with threshold)
### Migration Script Structure
```

---

### Prompt D-DEVOPS-01: Helm Chart for Desk Services

```
[ROLE]
You are a Senior DevOps Engineer specializing in Kubernetes deployment
for multi-tenant .NET SaaS microservices on AKS.

[CONTEXT]
Product: AppLogica Desk — Kubernetes Deployment
Services:
  - desk-api (main REST API)
  - desk-worker (Hangfire background jobs — SLA engine, escalations, reports)
  - desk-signalr (SignalR real-time hub, separate deployment)
Tech: AKS, Helm 3, Azure Container Registry, Key Vault, Application Insights
ATLAS Platform: Shares identity-service, tenant-service, api-gateway, event-bus

[TASK]
Generate Helm chart configuration for all AppLogica Desk services.

[CONSTRAINTS]
- desk-worker must NOT be exposed externally (no ingress, ClusterIP only)
- desk-signalr requires sticky sessions (Azure Application Gateway affinity)
- All secrets via Azure Key Vault CSI driver — no plain secrets in values.yaml
- HPA: desk-api min 2 / max 10 pods; desk-worker min 1 / max 5 pods
- Resource requests/limits must be defined for all containers
- Readiness probe: /health/ready; Liveness probe: /health/live
- Anti-affinity rules: spread pods across availability zones

[OUTPUT FORMAT]
### Chart.yaml
### values.yaml (with environment-specific override placeholders)
### deployment.yaml (for each service)
### service.yaml (for each service)
### ingress.yaml (desk-api and desk-signalr only)
### hpa.yaml (for desk-api and desk-worker)
### configmap.yaml
### Notes on Key Vault integration
```

---

## Section 6 — Testing & Quality

### Prompt D-QA-01: SLA Engine Test Suite

```
[ROLE]
You are a Senior QA Engineer and Test Architect specializing in
business-logic testing for enterprise SaaS platforms.

[CONTEXT]
Product: AppLogica Desk — SLA Engine Test Suite
Tech: xUnit, FluentAssertions, Testcontainers (PostgreSQL), Moq
Test Targets:
- SLA calculation accuracy (response time, resolution time)
- Business hours computation (with timezone and holiday calendar)
- Pause/resume time accounting
- Breach prediction algorithm
- Priority change mid-SLA recalculation

[TASK]
Generate a comprehensive test suite for the AppLogica Desk SLA engine,
covering all edge cases defined in the architecture.

[CONSTRAINTS]
- Cover at minimum: 20 unit test cases and 5 integration test cases
- Edge cases MUST include:
  (a) Ticket created 1 minute before end of business hours
  (b) Ticket paused across a weekend boundary
  (c) Priority upgraded from Medium to Critical mid-SLA
  (d) Public holiday on response deadline day
  (e) Tenant in UTC+3 with SLA deadline crossing DST transition
- All integration tests use Testcontainers (real PostgreSQL, not mocks)
- Test names must be descriptive: Given_[Condition]_When_[Action]_Then_[Expected]

[OUTPUT FORMAT]
### Test Class Structure
### Unit Tests (SLA Calculation)
### Unit Tests (Business Hours)
### Unit Tests (Pause/Resume)
### Unit Tests (Breach Prediction)
### Integration Tests (end-to-end SLA lifecycle)
### Edge Case Test Matrix
```

---

## Appendix: Prompt Quick Reference

| Prompt ID | Section | Purpose |
|---|---|---|
| D-ARCH-01 | Architecture | Incident domain model |
| D-ARCH-02 | Architecture | SLA engine design |
| D-ARCH-03 | Architecture | Change Management CAB workflow |
| D-ARCH-04 | Architecture | CMDB design |
| D-BE-01 | Backend | Incident API handler |
| D-BE-02 | Backend | Service catalog fulfillment engine |
| D-BE-03 | Backend | Knowledge base with AI generation |
| D-FE-01 | Frontend | Agent unified inbox |
| D-FE-02 | Frontend | Change calendar UI |
| D-FE-03 | Frontend | SLA dashboard |
| D-AI-01 | AI | ITSM Copilot system prompt |
| D-AI-02 | AI | Incident smart classification |
| D-AI-03 | AI | RAG knowledge retrieval pipeline |
| D-AI-04 | AI | Anomaly detection + NL narratives |
| D-DB-01 | Database | Core schema DDL |
| D-DEVOPS-01 | Infrastructure | Helm chart for Desk services |
| D-QA-01 | Testing | SLA engine test suite |

---

*AppLogica Desk — AI Prompts Library*  
*ATLAS-DESK-PROMPTS-v1.0 | March 01, 2026*  
*CTO Office, AppLogica*
